#ifndef SOMMETCOLORE_H
#define SOMMETCOLORE_H

class SommetColore : public Sommet
{
public:
    SommetColore();
};

#endif // SOMMETCOLORE_H
