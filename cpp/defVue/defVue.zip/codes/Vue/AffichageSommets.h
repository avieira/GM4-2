
#ifndef AFFICHAGESOMMETS_H
#define AFFICHAGESOMMETS_H

#include <string>
#include vector



namespace Vue {


/*!
  * \class AffichageSommets
  * \brief Conteneur de des champs pour les sommets
  * \author TO DEFINE
  * \version 1.0
  * \date avril 2014
  * \bug None
  * \warning None
  *
  * Affichage de la liste des sommets actuellement en mémoire, conteneur avec tous les champs sommets créés. Contient dont une liste de champSommet qu'il affiche.
  */

class AffichageSommets
{
public:

	// Constructors/Destructors
	//  


	/**
	 * Empty Constructor
	 */
	affichageSommets ( );

	/**
	 * Empty Destructor
	 */
	virtual ~affichageSommets ( );

	// Static Public attributes
	//  

	// Public attributes
	//  


	// Public attribute accessor methods
	//  


	// Public attribute accessor methods
	//  


protected:

	// Static Protected attributes
	//  

	// Protected attributes
	//  

public:


	// Protected attribute accessor methods
	//  

protected:

public:


	// Protected attribute accessor methods
	//  

protected:


private:

	// Static Private attributes
	//  

	// Private attributes
	//  

public:


	// Private attribute accessor methods
	//  

private:

public:


	// Private attribute accessor methods
	//  

private:



};
}; // end of package namespace

#endif // AFFICHAGESOMMETS_H
