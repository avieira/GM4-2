
#ifndef FENETREAFFICHAGEGRAPH_H
#define FENETREAFFICHAGEGRAPH_H
#include "Obs/Observeur.h"

#include <string>
#include vector


using Obs::Observeur;

namespace Vue {


/*!
  * \class FenetreAffichageGraph
  * \brief Fenêtre pour afficher le graphe
  * \author TO DEFINE
  * \version 1.0
  * \date avril 2014
  * \bug None
  * \warning Utilisation de graphViz à envisager.
  *
  * Fenêtre d'affichage du graphe (sommets avec couleurs, arcs avec valeur, orientation....). 
  */

class FenetreAffichageGraph : virtual public Observeur
{
public:

	// Constructors/Destructors
	//  


	/**
	 * Empty Constructor
	 */
	fenetreAffichageGraph ( );

	/**
	 * Empty Destructor
	 */
	virtual ~fenetreAffichageGraph ( );

	// Static Public attributes
	//  

	// Public attributes
	//  


	// Public attribute accessor methods
	//  


	// Public attribute accessor methods
	//  


protected:

	// Static Protected attributes
	//  

	// Protected attributes
	//  

public:


	// Protected attribute accessor methods
	//  

protected:

public:


	// Protected attribute accessor methods
	//  

protected:


private:

	// Static Private attributes
	//  

	// Private attributes
	//  

public:


	// Private attribute accessor methods
	//  

private:

public:


	// Private attribute accessor methods
	//  

private:



};
}; // end of package namespace

#endif // FENETREAFFICHAGEGRAPH_H
