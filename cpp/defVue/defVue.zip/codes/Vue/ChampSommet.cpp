#include "champSommet.h"

// Constructors/Destructors
//  

champSommet::champSommet ( ) {
}

champSommet::~champSommet ( ) { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  


