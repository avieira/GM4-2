
#ifndef CHAMPSOMMET_H
#define CHAMPSOMMET_H
#include "Obs/Observeur.h"

#include <string>
#include vector


using Obs::Observeur;

namespace Vue {


/*!
  * \class ChampSommet
  * \brief Liste de sommets
  * \author TO DEFINE
  * \version 1.0
  * \date avril 2014
  * \bug None
  * \warning None
  *
  * Affichage d'information sur un sommet actuellement en mémoire. Notifié par le métier à chaque modification du dit sommet.
  */

class ChampSommet : virtual public Observeur
{
public:

	// Constructors/Destructors
	//  


	/**
	 * Empty Constructor
	 */
	champSommet ( );

	/**
	 * Empty Destructor
	 */
	virtual ~champSommet ( );

	// Static Public attributes
	//  

	// Public attributes
	//  


	// Public attribute accessor methods
	//  


	// Public attribute accessor methods
	//  


protected:

	// Static Protected attributes
	//  

	// Protected attributes
	//  

public:


	// Protected attribute accessor methods
	//  

protected:

public:


	// Protected attribute accessor methods
	//  

protected:


private:

	// Static Private attributes
	//  

	// Private attributes
	//  

public:


	// Private attribute accessor methods
	//  

private:

public:


	// Private attribute accessor methods
	//  

private:



};
}; // end of package namespace

#endif // CHAMPSOMMET_H
