
#ifndef CONTENEURGENERAL_H
#define CONTENEURGENERAL_H

#include <string>
#include vector



namespace Vue {


/*!
  * \class ConteneurGeneral
  * \brief Fenêtre générale de l'IHM
  * \author TO DEFINE
  * \version 1.0
  * \date avril 2014
  * \bug None
  * \warning None
  *
  * Conteneur avec tous les composants graphiques de l'application. En soit, ne sert pas à plus qu'à contenir...
  */

class ConteneurGeneral
{
public:

	// Constructors/Destructors
	//  


	/**
	 * Empty Constructor
	 */
	conteneurGeneral ( );

	/**
	 * Empty Destructor
	 */
	virtual ~conteneurGeneral ( );

	// Static Public attributes
	//  

	// Public attributes
	//  


	// Public attribute accessor methods
	//  


	// Public attribute accessor methods
	//  


protected:

	// Static Protected attributes
	//  

	// Protected attributes
	//  

public:


	// Protected attribute accessor methods
	//  

protected:

public:


	// Protected attribute accessor methods
	//  

protected:


private:

	// Static Private attributes
	//  

	// Private attributes
	//  

public:


	// Private attribute accessor methods
	//  

private:

public:


	// Private attribute accessor methods
	//  

private:



};
}; // end of package namespace

#endif // CONTENEURGENERAL_H
