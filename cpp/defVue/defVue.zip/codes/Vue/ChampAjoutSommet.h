
#ifndef CHAMPAJOUTSOMMET_H
#define CHAMPAJOUTSOMMET_H

#include <string>
#include vector



namespace Vue {


/*!
  * \class ChampAjoutSommet
  * \brief Champ d'ajout d'un sommet
  * \author TO DEFINE
  * \version 1.0
  * \date avril 2014
  * \bug None
  * \warning None
  *
  * Champ textuel pour créer un nouveau sommet. Lien avec le métier pour la création.
  */

class ChampAjoutSommet
{
public:

	// Constructors/Destructors
	//  


	/**
	 * Empty Constructor
	 */
	champAjoutSommet ( );

	/**
	 * Empty Destructor
	 */
	virtual ~champAjoutSommet ( );

	// Static Public attributes
	//  

	// Public attributes
	//  


	// Public attribute accessor methods
	//  


	// Public attribute accessor methods
	//  


protected:

	// Static Protected attributes
	//  

	// Protected attributes
	//  

public:


	// Protected attribute accessor methods
	//  

protected:

public:


	// Protected attribute accessor methods
	//  

protected:


private:

	// Static Private attributes
	//  

	// Private attributes
	//  

public:


	// Private attribute accessor methods
	//  

private:

public:


	// Private attribute accessor methods
	//  

private:



};
}; // end of package namespace

#endif // CHAMPAJOUTSOMMET_H
