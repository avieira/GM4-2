#ifndef XMLTREE_H
#define XMLTREE_H

#include <QDomDocument>
#include <QHash>
#include <QIcon>
#include <QTreeWidget>

#include "Model/sommetcolore.h"
#include "Model/sommetvalue.h"
#include "Model/graphe.h"


class XMLTree : public QTreeWidget
{
    Q_OBJECT

public:
    XMLTree(QWidget *parent = 0, Graphe *graph=new Graphe());

    bool ouvrir(QIODevice *device);
    bool enregistrer(QIODevice *device);
    void ajouterSommet(Sommet*);
    void ajouterSommet(SommetColore*);
    void ajouterSommet(SommetValue*);
    /*void ajouterSommet(SommetValueColore*);*/
    void ajouterArc(Arete*);

private slots:
    void updateDomElement(QTreeWidgetItem *item, int column);

private:
    void parseGraphe(const QDomElement &element,
                            QTreeWidgetItem *parentItem = 0);
    void parseElement(const QDomElement &element,
                            QTreeWidgetItem *parentItem,
                            Sommet* sommet);
    void parseElement(const QDomElement &element,
                            QTreeWidgetItem *parentItem,
                            Arete* arc);
    QTreeWidgetItem *createItem(const QDomElement &element,
                                QTreeWidgetItem *parentItem = 0);
    QDomDocument domDocument;
    QHash<QTreeWidgetItem *, QDomElement> domElementForItem;

    Graphe* graphe;
};

#endif // XMLTREE_H
