
#ifndef MENUVUE_H
#define MENUVUE_H

#include <string>
#include vector



namespace Vue {


/*!
  * \class MenuVue
  * \brief Barre de menu de l'IHM
  * \author TO DEFINE
  * \version 1.0
  * \date avril 2014
  * \bug None
  * \warning None
  *
  * Barre de menu dans l'interface graphique, donne accès à différentes options et communique avec le métier. Ammené à évoluer.
  */

class MenuVue
{
public:

	// Constructors/Destructors
	//  


	/**
	 * Empty Constructor
	 */
	menuVue ( );

	/**
	 * Empty Destructor
	 */
	virtual ~menuVue ( );

	// Static Public attributes
	//  

	// Public attributes
	//  


	// Public attribute accessor methods
	//  


	// Public attribute accessor methods
	//  


protected:

	// Static Protected attributes
	//  

	// Protected attributes
	//  

public:


	// Protected attribute accessor methods
	//  

protected:

public:


	// Protected attribute accessor methods
	//  

protected:


private:

	// Static Private attributes
	//  

	// Private attributes
	//  

public:


	// Private attribute accessor methods
	//  

private:

public:


	// Private attribute accessor methods
	//  

private:



};
}; // end of package namespace

#endif // MENUVUE_H
