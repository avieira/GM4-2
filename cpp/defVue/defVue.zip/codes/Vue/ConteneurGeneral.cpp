#include "conteneurGeneral.h"

// Constructors/Destructors
//  

conteneurGeneral::conteneurGeneral ( ) {
}

conteneurGeneral::~conteneurGeneral ( ) { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  


