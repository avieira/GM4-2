#ifndef FENETRE_H
#define FENETRE_H

#include <QMainWindow>
#include<QTabWidget>
#include<QPushButton>
#include<QComboBox>
#include <vector>

#include "Model/sommetcolore.h"
#include "Model/graphe.h"
#include "xmltree.h"
#include "implemgraphviz.h"


namespace Ui {
class Fenetre;
}

class Fenetre : public QMainWindow
{
    Q_OBJECT

public:
    explicit Fenetre(QWidget *parent = 0, Graphe *graph=new Graphe());
    ~Fenetre();

private slots:
    void slotButtonSommet();
    void slotButtonArc();
    void ouvrir();
    void enregistrer();
    void changeAttributSommet();
    void changeAttributArc();

private:
    Ui::Fenetre *ui;

    ImplemGraphviz *affichageSVG;
    XMLTree *xmltree;
    QTabWidget *conteneurChamps;
    QPushButton *pushButtonArc;
    QPushButton *pushButtonSommet;
    QLineEdit *lineEditSommet;
    QStringList listeFormes;
    QComboBox *comboBoxArc1;
    QComboBox *comboBoxArc2;

    std::vector<Sommet*> *listeSommets;
    std::vector<Arete*> *listeArcs;

    void creerActions();

    void modifSommetNom(Sommet*);
    void modifSommetForme(Sommet*);
    void modifSommetCouleur(SommetColore *);
    void modifArcDepart(Arete*);
    void modifArcArrivee(Arete*);

};

#endif // FENETRE_H

