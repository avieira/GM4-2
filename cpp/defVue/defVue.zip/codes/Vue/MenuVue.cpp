#include "menuVue.h"

// Constructors/Destructors
//  

menuVue::menuVue ( ) {
}

menuVue::~menuVue ( ) { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  


