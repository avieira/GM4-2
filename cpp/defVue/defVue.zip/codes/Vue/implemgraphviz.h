#ifndef ImplemGraphviz_H
#define ImplemGraphviz_H

#include<QGraphicsView>
#include<QHash>
#include <QSvgWidget>
#include<vector>

#include <graphviz/gvc.h>

#include"Model/graphe.h"
#include"Model/grapheoriente.h"
#include"Model/graphecolore.h"


class ImplemGraphviz : public QSvgWidget
{
public:
    ImplemGraphviz(QWidget *parent = 0, Graphe *graphe=new Graphe());
    ImplemGraphviz(QWidget *parent = 0, GrapheOriente *graphe=new GrapheOriente());
    void drawGraph();

private:
    Graphe* graphe;
    QString lienSVG;
    Agraph_t* G;
    QHash<Sommet*, Agnode_t*> tableNodes;
    QHash<Arete*, Agedge_t*> tableEdges;

    void creerListeNodes(Graphe *graphe);
    void creerListeNodes(GrapheColore *graphe);
    void creerListeEdges();
};

#endif // ImplemGraphviz_H
