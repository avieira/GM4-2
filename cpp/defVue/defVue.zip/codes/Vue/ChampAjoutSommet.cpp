#include "champAjoutSommet.h"

// Constructors/Destructors
//  

champAjoutSommet::champAjoutSommet ( ) {
}

champAjoutSommet::~champAjoutSommet ( ) { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  


