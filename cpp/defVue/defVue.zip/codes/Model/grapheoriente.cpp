#include "grapheoriente.h"

GrapheOriente::GrapheOriente()
{
}
