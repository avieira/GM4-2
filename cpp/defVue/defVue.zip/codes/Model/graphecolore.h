#ifndef GRAPHECOLORE_H
#define GRAPHECOLORE_H

#include"Model/graphe.h"
#include"Model/sommetcolore.h"

class GrapheColore : public Graphe
{
public:
    GrapheColore();
};

#endif // GRAPHECOLORE_H
