#ifndef GRAPHEORIENTE_H
#define GRAPHEORIENTE_H

#include"graphe.h"

class GrapheOriente : public Graphe
{
public:
    GrapheOriente();
};

#endif // GRAPHEORIENTE_H
