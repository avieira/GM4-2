#include "graphecolore.h"

GrapheColore::GrapheColore()
{
}
